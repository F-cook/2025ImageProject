% this function is used to obtain the SHA-256 value of a matrix
% the input should be a number matrix




function sha_value = SHA_256_value_obtain_matrix(A)


A_vec = reshape(A,1,[]);

B = num2str(A_vec);



sha_value = SHA_256_value_obtain(B);


end















