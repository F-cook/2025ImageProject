% this function is used to count the rate of different numbers in a matrix
function rate_x = real_prob(x,err_im)



% obtain the matrix which only include errors

[M,N] = size(err_im);


% maybe the inline function is more fast

all_err_im = err_im(2:M,2:N);



[M,N] = size(all_err_im);


count_x = 0;

for i = 1:1:M
    for j = 1:1:N
        if all_err_im(i,j) == x
            count_x = count_x + 1;
        end
    end
end

rate_x = count_x / (M*N);



end



