% this function is the inversed process of diffusion


function A_vector_r = diffuse_backward(A_D_vector,T)



[M,N] = size(A_D_vector);




for i = M*N:-1:2
    if mod(i,2) == 0
        A_vector_r(i) = mod(bitxor(bitxor(A_D_vector(i-1),T(i)),A_D_vector(i)),256);
    else
        A_vector_r(i) = mod( A_D_vector(i) - A_D_vector(i-1) - T(i),256);
    end
end



A_vector_r(1) = mod(bitxor(A_D_vector(1),T(1)),256);




end



