% this page is used to complete the square matrix process


% load the data
ini_im = double(imread("5.1.09.tiff"));


% compress the image
imi_compressed = final_imi_compressed_obtain(ini_im);


% obtain the square image
imi_compressed_square = square_image_obtain(imi_compressed);


% recover, obtain the compressed image
imi_compressed_r = compressed_im_from_square(imi_compressed_square);


% detemine it is the same or not
judge_value = isequal(imi_compressed,imi_compressed_r);







