% this page is used to save images


% load the data
% im_ini = double(imread("figures\5.1.10.tiff"));



% save the data
imwrite(uint8(im_ini),'figures_output\5.1.10_original.png');

imwrite(uint8(final_im),'figures_output\5.1.10_cte.png');

imwrite(uint8(im_ini_r),'figures_output\5.1.10_recovered.png');






