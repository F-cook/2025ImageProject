% this function is used to recover the original image 
% with predict error matrix


function ini_im_re = recover_error(err_im)


% the only information which can be used for recovering is err_im

[M,N] = size(err_im);

% construct the image for recovering 

ini_im_re = zeros(3,3);



% copy the first row and col from err_im to ini_im_re

for i = 1:1:M
    ini_im_re(i,1) = err_im(i,1);
end

for j = 1:1:N
    ini_im_re(1,j) = err_im(1,j);
end




% recover the rest elements 


for i = 2:1:M
    for j = 2:1:N
        a = ini_im_re(i,j-1);
        b = ini_im_re(i-1,j);
        c = ini_im_re(i-1,j-1);
        if c >= max(a,b)
            x = min(a,b);
        elseif c <= min(a,b)
            x = max(a,b);
        else
            x = a+b-c;
        end
        ini_im_re(i,j) = x + err_im(i,j);
    end
end








end


