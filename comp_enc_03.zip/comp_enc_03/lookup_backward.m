% this page is used to desctibe the funciton which go through the following
% number, position, position thransformed number


function ori_number = lookup_backward(a,lookup_table)


% Initialize coordinates

row = 0;
col = 0;


for i = 1:1:16
    for j = 1:1:16
        if lookup_table(i,j) == a
            row = i;
            col = j;
        end
    end
end

% transform the coordinates into bin number


switch row
    case 1
        m = '0000';
    case 2
        m = '0001';
    case 3
        m = '0010';
    case 4
        m = '0011';
    case 5
        m = '0100';
    case 6
        m = '0101';
    case 7
        m = '0110';
    case 8 
        m = '0111';
    case 9
        m = '1000';
    case 10
        m = '1001';
    case 11
        m = '1010';
    case 12
        m = '1011';
    case 13
        m = '1100';
    case 14
        m = '1101';
    case 15
        m = '1110';
    case 16 
        m = '1111';
end
        

switch col
    case 1
        n = '0000';
    case 2
        n = '0001';
    case 3
        n = '0010';
    case 4
        n = '0011';
    case 5
        n = '0100';
    case 6
        n = '0101';
    case 7
        n = '0110';
    case 8 
        n = '0111';
    case 9
        n = '1000';
    case 10
        n = '1001';
    case 11
        n = '1010';
    case 12
        n = '1011';
    case 13
        n = '1100';
    case 14
        n = '1101';
    case 15
        n = '1110';
    case 16 
        n = '1111';
end
        

%{
% splicing m and n

str_m = num2str(m);
str_n = num2str(n);
%}


str_new_num = [m,n];

% new_number_bin = str2num(str_new_num);
ori_number = bin2dec(str_new_num);




end




