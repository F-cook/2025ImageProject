% this function is used to obtain the theory of 
% different values distributions


function TSGD_matrix = TSGD_prob_matrix(P)



% create a matrix which has three rows, the first is pixel value
% the second is probability of theory, the third is real 


TSGD_matrix = zeros(2,255*2+1);


% assignment to the first row

for i = 1:1:511
    TSGD_matrix(1,i) = i - 256;
end


% assignment to the second row


for i = 1:1:511
    TSGD_matrix(2,i) = TSGD_prob(P,TSGD_matrix(1,i));
end







end

