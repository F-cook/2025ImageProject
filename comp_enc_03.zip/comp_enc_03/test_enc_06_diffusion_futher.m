% this page is used to finish the diffusion process


% create the data

A_vector = [199 29 35 4 15];
T = [2 33 44 233 200];

% test the diffusion functions

A_D_vector = diffuse_forward(A_vector,T);
A_vector_r = diffuse_backward(A_D_vector,T);















