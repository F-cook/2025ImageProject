% this page test the matrix and think some idea for Huffman encoding



% obtain the necessary data


% obtain the ini_im and new_im, and pred_error_im

ini_im = double(imread("5.1.09.tiff"));

err_im = predict_complete(ini_im);

% obtain the parameter of TSGD 

P = TSGD_par(err_im);

% obtain the probability matrix

useful_matrix = TSGD_prob_matrix(P);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% obtain both the theory and real probability matrix

two_prob_matrix = all_prob_matrix(P,err_im);


% compare two probabilities with figure


x_coordinate = two_prob_matrix(1,:);
y_coordinate_1 = two_prob_matrix(2,:);
y_coordinate_2 = two_prob_matrix(3,:);
plot(x_coordinate,y_coordinate_1,'-r',x_coordinate,y_coordinate_2,'-b');
% imshow();









