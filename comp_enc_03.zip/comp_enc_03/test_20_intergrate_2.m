% this page is used to obtain the four important part after compression


% the completed prediction error image, the first col and row 
% the compressed errors
% P, which is the parameter of TSGD
% k, which is the complement information of bin to pixel 



tic


% load the image 

ini_im = double(imread("5.1.09.tiff"));

% obtain the four part after compression

[err_im,imi_pixel,P,k] = compress_four_part(ini_im);




[M,N] = size(err_im);

% test the error matrix

all_error_matrix = err_im(2:M,2:N);








% recover the all_error_matrix with the three part


all_error_matrix_r = three_part_all_err(imi_pixel,P,k);


% recover the original image with err_im

ini_im_r = recover_error(err_im);

toc









