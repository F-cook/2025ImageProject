% this page is used to compressed and obtain square image
% maybe recover the compressed image is easy


% load the data
ini_im = double(imread("5.1.09.tiff"));


% compress the image
imi_compressed = final_imi_compressed_obtain(ini_im);




% obtain the square image

imi_compressed_square = square_image_obtain(imi_compressed);











