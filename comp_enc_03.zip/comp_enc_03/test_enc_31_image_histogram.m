% this page is used to obtian the histogram of images


% load the image
im_ini = double(imread("useful_figures\5.3.02.tiff"));


% obatin the histograms

imhist(im_ini);












