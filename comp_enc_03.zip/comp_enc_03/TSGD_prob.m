% this function is used to obtian the probability of TSGD with its PMF


function prob = TSGD_prob(P,k)

% obtian the probability with PMF of TSGD

prob = (1-P)/(1+P)*P^(abs(k));

end


