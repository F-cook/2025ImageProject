% this page is used to complete the SHA compute and 
% key and sybkey distribution




% test the SHA-value

string_constucted = 'some string'; 

string_create = 'my heart will go on';

string_3 = '01210';

sha_value_2 = SHA_256_value_obtain(string_create);

sha_value_1 = SHA_256_value_obtain(string_constucted);

sha_value_3 = SHA_256_value_obtain(string_3);


% test the number matrix (vector) , transform it into char matrix


A = [12 23 47 33 45];

B = num2str(A);

sha_value_4 = SHA_256_value_obtain(B);














