% this page is used to test the split function


file_name = "5.1.09.tiff";

[L0,R0] = im_split(file_name);

% im = double(imread(file_name));








