% this function is used to return the CA iteration results
% it supports different rules

% the second parameter num is iteration number, the last is the rule number


function [rec_matrix,rec_matrix_flip] = CA_variable_iteration(ini,num,rule_num)




[~,N] = size(ini);


rec_matrix = zeros(num,N);




% iteration


for i = 1:1:num
    rec_matrix(i,:) = ini;
    ini = CA_evolve_rule_variable_vec(ini,rule_num);
end


% obtain the fliped matrix, up to down


rec_matrix_flip = flipud(rec_matrix);






end