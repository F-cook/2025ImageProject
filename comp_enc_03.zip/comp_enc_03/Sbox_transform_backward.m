% This function is described the process of inversed S-box transforsition


function old_vector = Sbox_transform_backward(new_vector,lookup_table)



[~,length] = size(new_vector);


for i = 1:1:length
    old_vector(i) = lookup_backward(new_vector(i),lookup_table);
end



end

