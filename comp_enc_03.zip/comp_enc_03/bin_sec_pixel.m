% this function is used to transform a binary sequence into pixels
% the proceeding include complement to the multiple of 8 and coding


function [k,imi_pixel] = bin_sec_pixel(original_imi)

% load the data

imi_bin = original_imi;




% the number of complementary is k

k = 0;


% complement bits until it is the multiple of 8

while mod(length(imi_bin),8) ~= 0
    imi_bin = [imi_bin,0];
    k = k + 1;
end



% transform all the binary elements 


[~,N] = size(imi_bin);

imi_pixel = [];

for i = 1:8:N
    pixel_bin = imi_bin(i:i+7);
    pixel_dec = bin2dec(num2str(pixel_bin));
    imi_pixel = [imi_pixel,pixel_dec];
end





end


