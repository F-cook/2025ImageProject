% finally, the encryption process is coming


% the following process may be implemented

% 1. read image and split it into two parts

% left part 

%%% 2. substitution
%%% 3. diffusion

% right part

%%% 4. SHA
%%% 5. PRNG CA

% 6. combination



% firstly, test the normal condition
% secondly, adapt satellite images







