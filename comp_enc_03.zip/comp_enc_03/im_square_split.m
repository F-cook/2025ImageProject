% this function is used to seperate a square matrix into two parts

function [im_L0,im_R0] = im_square_split(im_ini)



% obtain the vector
im_vec = reshape(im_ini,1,[]);



[~,N] = size(im_vec);



% function ceil() is used to round up of a integer

length_one = ceil(N/2);


im_L0 = im_vec(1:length_one);

im_R0 = im_vec(length_one+1:N);



end







