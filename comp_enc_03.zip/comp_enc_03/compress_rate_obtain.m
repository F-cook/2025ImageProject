% this function is used to compute the compressed rate directly
function rate = compress_rate_obtain(ini_im,imi_compressed)



[MM,NN] = size(ini_im);
[M,N] = size(imi_compressed);

rate = (M*N)/(MM*NN);



end


