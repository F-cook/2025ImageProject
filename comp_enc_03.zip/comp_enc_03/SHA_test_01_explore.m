% This is the first page to explore the hash function


% finally, the answer is found in the weblink of 
% https://stackoverflow.com/questions/49613043/convert-a-string-into-hash-value-in-matlab






%{


% simple example
% hash value for a string


str = 'hello world';
meth = 'SHA-1';

% hash_value = hash(str,meth);


% hash_value = hash(


%}




%{




% another way

% create a ???
hasher = System.Security.Cryptography.SHA256Managed();




% create a word

word = 'kiss the world';

% transform the word

word_in = uint8(word);

% compute the hash value 

% hash_value = step(hasher,word_in);
% hash_value = step(hasher,word);


%}





% the third method



% compute the sha-256

string = 'some string'; 

%{

sha256hasher = System.Security.Cryptography.SHA256Managed;
sha256 = uint8(sha256hasher.ComputeHash(uint8(string)));

hashvalue = dec2hex(sha256);

%}



sha1hasher = System.Security.Cryptography.SHA1Managed;
sha1= uint8(sha1hasher.ComputeHash(uint8(string)));
hashvalue = dec2hex(sha1);




















