% this function is used to record the decryption of one round


function [L0_r,R0_r] = dec_round(L1,R1,subkey_1)

% read the Sbox

AES_Sbox_dec = readmatrix("AESboxDec.txt");




% recover the R0 directly

R0_r = L1;


% recover the L0, through the inverse of diffusion and substitution



% recover the random nunmbers

% SHA value obtain

R0_SHA_r = SHA_256_value_obtain_matrix(R0_r);


% construct the initial value of CA PRNG 

CA_ini_r = [R0_SHA_r,subkey_1];


% create the random numbers with CA PRNG

size_need_r = length(R1);
% L0 has the same length with R1

random_numbers_r = CA_PRNG(CA_ini_r,size_need_r);



L0_s_d_r = R1;


% inverse diffusion

L0_s_r = diffuse_backward(L0_s_d_r,random_numbers_r);

% inverse substitution

L0_r = Sbox_transform_backward(L0_s_r,AES_Sbox_dec);




end

