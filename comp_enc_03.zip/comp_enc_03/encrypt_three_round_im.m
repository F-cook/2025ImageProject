% this page is an improved version of encryption



function final_im = encrypt_three_round_im(im_compressed_square,key)




% split it into two part, L0 and R0

[L0,R0] = im_square_split(im_compressed_square);



% encryption the first round

[L1,R1] = enc_round(L0,R0,key);

% encrypt the remaining rounds

[L2,R2] = enc_round(L1,R1,key);

[L3,R3] = enc_round(L2,R2,key);


final_im_vec = [L3,R3];

final_im = reshape(final_im_vec,sqrt(length(final_im_vec)),sqrt(length(final_im_vec)));




end









