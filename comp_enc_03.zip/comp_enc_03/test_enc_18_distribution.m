% this page is used to test the distribution of pixels



sample_matrix = randi([0,255],256);

histogram(sample_matrix,50);


% that is it











