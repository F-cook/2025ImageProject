% this page is used to improve the encryption


rng(124);
secret_key = randi([0,1],1,128);




% load the image
im_ini = double(imread("useful_figures\5.3.02.tiff"));



% change pixel for NPCR or UACI
% im_ini(1,1) = 100; 




% im_ini = [12 25 30; 52 23 255; 36 23 46];

im_cipher = encrypt_three_round_im(im_ini,secret_key);




% test the recover

% im_ini_r = decryption_three_round_im(im_cipher,secret_key);

% imshow(uint8(im_ini_r));

% 



% save the encryption image

% imwrite(uint8(im_cipher),'encryption_results\5.3.02_enc_01.png');

