% this page continues to transform 



% load the data 

imi_bin = [0 1 0 1 0 0 1 0 0 1];

% record the original data

original_imi = imi_bin;






% the number of complementary is k

k = 0;

% add the new elements directly with judge the vector length directly

while mod(length(imi_bin),8) ~= 0
    imi_bin = [imi_bin,0];
    k = k + 1;
end





% transform all the binary elements 


[~,N] = size(imi_bin);

imi_pixel = [];

for i = 1:8:N
    pixel_bin = imi_bin(i:i+7);
    pixel_dec = bin2dec(num2str(pixel_bin));
    imi_pixel = [imi_pixel,pixel_dec];
end





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% recover the imi_pixel 


imi_bin_r = [];
    

[~,N] = size(imi_pixel);


for count = 1:1:N
    pixel_first_dec = imi_pixel(count);
    pixel_first_bin = dec2bin((pixel_first_dec),8);
    pixel_vector = [];

    for i = 1:1:8
        pixel_vector(i) = str2num(pixel_first_bin(i));
    end

    imi_bin_r = [imi_bin_r,pixel_vector];

end



original_imi_r = imi_bin_r(1:(length(imi_bin_r)-k));









