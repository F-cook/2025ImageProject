% this function is used to output the difference between two images


function err_im = diff_two_images(ini_im,new_im)


[M,N] = size(ini_im);



err_im = zeros(3,3);

for i = 1:1:M
    for j = 1:1:N
        err_im(i,j) = new_im(i,j) - ini_im(i,j);
    end
end




end






