% this function is used to transform the bin array to dec array


function dec_form_matrix = bin_array_to_dec_array(bin_array)


[~,N] = size(bin_array);

dec_form_matrix = [];



for i = 1:8:N
    bin_string = num2str(bin_array(i:i+7));
    dec_one_form = bin2dec(bin_string);
    dec_form_matrix = [dec_form_matrix,dec_one_form];
end




end


