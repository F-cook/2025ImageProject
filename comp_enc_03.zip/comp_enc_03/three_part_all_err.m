% this funciton is used to recover the original image 
% with four part which is the result of compression

function all_error_matrix_r = three_part_all_err(imi_pixel,P,k)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% construct the dict 


% obtain the probability matrix

useful_matrix = TSGD_prob_matrix(P);


% obtain the symbols and their frequency

symbols_err = useful_matrix(1,:);
freq_err = useful_matrix(2,:);


% construct the Huffman tree, which is very important, it is the core

[dict, ~] = huffmandict(symbols_err, freq_err);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




% recover the original image data
% with dict and imi_compressed_bin


original_imi_r = pixel_bin_sec(imi_pixel,k);


imi_compressed_bin = original_imi_r';


% recover 


all_error_matrix_vector_r = huffmandeco(imi_compressed_bin, dict);

n = sqrt(length(all_error_matrix_vector_r));

all_error_matrix_r = reshape(all_error_matrix_vector_r,n,n);




end
