% this page is used to obtain the compressed image from square image



% input: imi_compressed_square

% output: imi_compressed



if imi_compressed_square(end-1) == 0
    count_k = imi_compressed_square(end);
else
    count_k = imi_compressed_square(end) * 255 + imi_compressed_square(end-1);
end

[M,N] = size(imi_compressed_square);

original_length = M*N - count_k;

imi_compressed_r = imi_compressed_square(1:original_length);





judge_value = isequal(imi_compressed,imi_compressed_r);








