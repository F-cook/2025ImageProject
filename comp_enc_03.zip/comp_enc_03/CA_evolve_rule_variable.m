% this function is used to transform the cells with its two neighbors
% it supports different rules


function value_cur = CA_evolve_rule_variable(value_pre_left,value_pre,value_pre_right,rule_num)


% create a new combination for judgement

comb = [value_pre_left,value_pre,value_pre_right];

comb_str = num2str(comb);


% obtain the information about rule 

rec_matrix = rule_to_matrix(rule_num);



% obtain the new value according to the rule

switch comb_str
    case '1  1  1'
        value_cur = rec_matrix(1);
    case '1  1  0'
        value_cur = rec_matrix(2);
    case '1  0  1'
        value_cur = rec_matrix(3);
    case '1  0  0'
        value_cur = rec_matrix(4);


    case '0  1  1'
        value_cur = rec_matrix(5);
    case '0  1  0'
        value_cur = rec_matrix(6);
    case '0  0  1'
        value_cur = rec_matrix(7);
    case '0  0  0'
        value_cur = rec_matrix(8);


    otherwise
        value_cur = 999;
end

end
