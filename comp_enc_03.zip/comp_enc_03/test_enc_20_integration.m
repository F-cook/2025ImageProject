% this page is used to test the complete enc function 



rng(124);
key_all = randi([0,1],1,240);


% load the image
im_ini = double(imread("figures\5.1.11.tiff"));

im_cipher = encrypt_three_round(im_ini,key_all);


% save the encryption image

% imwrite(uint8(im_cipher),'encryption_results\5.1.11_enc.png');






% test the recover

im_ini_r = decryption_three_round(im_cipher,key_all);

imshow(uint8(im_ini_r));

%{


%}

% change only one bit of key
% key_all(1) = 1;

