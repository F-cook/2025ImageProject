% this page is used to transform the format of the images



% load the image
im_ini = double(imread("useful_figures\5.3.02.tiff"));


% save the image using another format

imwrite(uint8(im_ini),'encryption_results\5.3.02.png');












