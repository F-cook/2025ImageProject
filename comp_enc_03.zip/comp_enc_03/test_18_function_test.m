% this page is used to summarise the previous functions




% load the data , suppose it has 10 bits

original_imi = [0 1 0 1 0 0 1 0 0 1];

% transform it into pixel values and with complement number

[k,imi_pixel] = bin_sec_pixel(original_imi);


% recover the original image data

original_imi_r = pixel_bin_sec(imi_pixel,k);











