% this page is used to seperate the complete error image to 
% its first row and first col



% load the data

ini_im = double(imread("5.1.09.tiff"));

err_im = predict_complete(ini_im);


% obtain the first row and first col of err_im
% directly obtian   A(1:2,3:4)


[M,~] = size(err_im);

err_im_first_row = err_im(1:1,:);

err_im_first_col_except_one = err_im(2:M,1);

err_im_first_col_except_one = err_im_first_col_except_one';


% conbine the two parts

err_im_first = [err_im_first_row,err_im_first_col_except_one];



% test the s mark

[err_im,imi_pixel,P,k,s] = compress_five_part(ini_im);






