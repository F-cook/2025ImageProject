% this page is used to read an image and split it into two parts
% may be the first doesn't have the same length with the second part 
% split it into two length as same as possible 



% read the image and use it double form

% im = imread("5.1.09.tiff");
% read it directly, the result is uint8


im = double(imread("5.1.09.tiff"));


% test image show function
% imshow(uint8(im));


% transform it into a vector

im_vec = reshape(im,1,[]);

im_vec_test = [im_vec,1];



% obtain the length

% [~,N] = size(im_vec_test);

[~,N] = size(im_vec);




% function ceil() is used to round up of a integer


length_one = ceil(N/2);

% length_two = N - length_one;

% obtain the two parts


% im_L0 = im_vec_test(1:length_one);

% im_R0 = im_vec_test(length_one+1:N);



im_L0 = im_vec(1:length_one);

im_R0 = im_vec(length_one+1:N);


% recover it , show the result


im_vec_r = [im_L0,im_R0];

im_r = reshape(im_vec_r,sqrt(N),sqrt(N));

imshow(uint8(im_r));



