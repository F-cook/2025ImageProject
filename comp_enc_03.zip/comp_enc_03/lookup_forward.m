% this page is used to describe the function which restore the number from
% the lookup table

function new_number = lookup_forward(ori_number,lookup_table)


new_number_bin = dec2bin(ori_number);

while length(new_number_bin) < 8
    new_number_bin = ['0',new_number_bin];
end

str_m = new_number_bin(1:4);

str_n = new_number_bin(5:8);


m = str2num(str_m);

n = str2num(str_n);




switch m
    case 0000
        row = 1;
    case 0001
        row = 2;
    case 0010
        row = 3;
    case 0011
        row = 4;
    case 0100
        row = 5;
    case 0101
        row = 6;
    case 0110
        row = 7;
    case 0111
        row = 8;
    case 1000
        row = 9;
    case 1001
        row = 10;
    case 1010
        row = 11;
    case 1011
        row = 12;
    case 1100
        row = 13;
    case 1101
        row = 14;
    case 1110
        row = 15;
    case 1111
        row = 16;
end




switch n
    case 0000
        col = 1;
    case 0001
        col = 2;
    case 0010
        col = 3;
    case 0011
        col = 4;
    case 0100
        col = 5;
    case 0101
        col = 6;
    case 0110
        col = 7;
    case 0111
        col = 8;
    case 1000
        col = 9;
    case 1001
        col = 10;
    case 1010
        col = 11;
    case 1011
        col = 12;
    case 1100
        col = 13;
    case 1101
        col = 14;
    case 1110
        col = 15;
    case 1111
        col = 16;
end


new_number = lookup_table(row,col);



end














