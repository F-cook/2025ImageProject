% this page is an improved version of decryption



function im_compressed_square_r = decryption_three_round_im(final_im,key)






% recover the vector

final_im_vec_r = reshape(final_im,1,[]);


[~,N] = size(final_im_vec_r);
length_one = ceil(N/2);
length_two = N - length_one;


L3_r = final_im_vec_r(1:length_two);
R3_r = final_im_vec_r(length_two+1:N);


% three round deryption


[L2_r,R2_r] = dec_round(L3_r,R3_r,key);

[L1_r,R1_r] = dec_round(L2_r,R2_r,key);

[L0_r,R0_r] = dec_round(L1_r,R1_r,key);


% show the original image

im_ini_vec_r = [L0_r,R0_r];

im_compressed_square_r = reshape(im_ini_vec_r,sqrt(length(im_ini_vec_r)),sqrt(length(im_ini_vec_r)));





end










