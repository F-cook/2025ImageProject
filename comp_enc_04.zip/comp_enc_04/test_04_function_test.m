% this page is used to test the new functions



% read the image


ini_im = double(imread("5.1.09.tiff"));


% obtain the prediction image

new_im = predict_im_jpegls(ini_im);


% obtain the diff matrix

% err_im = diff_two_images(ini_im,new_im);


% obtain the predicted error matrix


err_im = predict_error(ini_im,new_im);












% test the matrix sum

% sum(sum(err_im));
% 186360

























