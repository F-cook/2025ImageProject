% maybe as usual, modular addition and XOR


% an example of diffusion, which is basiclly the same

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%{

% forward process:

for i = 2:1:M*N
    if mod(i,2) == 0
        A_D_vector(i) = mod(bitxor(bitxor(A_D_vector(i-1),T(i)),A_vector(i)),256);
    else
        A_D_vector(i) = mod(A_D_vector(i-1) + A_vector(i) + T(i),256);
    end
end


% backward process


for i = M*N:-1:2
    if mod(i,2) == 0
        A_vector_r(i) = mod(bitxor(bitxor(A_D_vector(i-1),T(i)),A_D_vector(i)),256);
    else
        A_vector_r(i) = mod( A_D_vector(i) - A_D_vector(i-1) - T(i),256);
    end
end



%}


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



A_vector = [199 29 35 4 15];
T = [2 33 44 233 200];
[M,N] = size(A_vector);



A_D_vector = zeros(1,M*N);
A_D_vector(1) = A_vector(1);





% forward process:

for i = 2:1:M*N
    if mod(i,2) == 0
        A_D_vector(i) = mod(bitxor(bitxor(A_D_vector(i-1),T(i)),A_vector(i)),256);
    else
        A_D_vector(i) = mod(A_D_vector(i-1) + A_vector(i) + T(i),256);
    end
end


% inverse process:

A_vector_r(1) = A_D_vector(1);

for i = M*N:-1:2
    if mod(i,2) == 0
        A_vector_r(i) = mod(bitxor(bitxor(A_D_vector(i-1),T(i)),A_D_vector(i)),256);
    else
        A_vector_r(i) = mod( A_D_vector(i) - A_D_vector(i-1) - T(i),256);
    end
end










