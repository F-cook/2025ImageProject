% this page is used to make futher preparations for prediction pixels



% use a 3*3 matrix instead of image

ini_im = [1 2 3; 4 5 6 ; 7 8 9];


new_im = zeros(3,3);


[M,N] = size(ini_im);




% construct the new image 


% first, copy the first row and first col




for i = 1:1:M
    new_im(i,1) = ini_im(i,1);
end

for j = 1:1:N
    new_im(1,j) = ini_im(1,j);
end





for i = 2:1:M
    for j = 2:1:N
        a = ini_im(i,j-1);
        b = ini_im(i-1,j);
        c = ini_im(i-1,j-1);
        if c >= max(a,b)
            x = min(a,b);
        elseif c <= min(a,b)
            x = max(a,b);
        else
            x = a+b-c;
        end
        new_im(i,j) = x;
    end
end



% construct the prediction error matrix 


err_im = zeros(3,3);

for i = 1:1:M
    for j = 1:1:N
        err_im(i,j) = new_im(i,j) - ini_im(i,j);
    end
end















