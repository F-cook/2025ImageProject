% this function is used to output 256 bit hash value of a string
% with SHA-256

% the input must be a char matrix




function final_record_SHA_value = SHA_256_value_obtain(string_constucted)




% the following setence will output the SHA-256 value of string

sha_hasher = System.Security.Cryptography.SHA256Managed;
% sha1hasher = System.Security.Cryptography.SHA1Managed;

sha_hasher= uint8(sha_hasher.ComputeHash(uint8(string_constucted)));
% hashvalue = dec2hex(sha_hasher);



final_value = dec2bin(sha_hasher);


[M,N] = size(final_value);


% construct a matirx to record the hash value

record_matrix = [];

for i = 1:1:M
    for j = 1:1:N
        record_matrix(i,j) = str2num(final_value(i,j));
    end
end


record_matrix_T = record_matrix';

final_record_SHA_value = reshape(record_matrix_T,1,256);



end
