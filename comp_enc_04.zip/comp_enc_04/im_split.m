% this function is used to split the image vector into two parts

function [im_L0,im_R0] = im_split(image_file)


% read
im = double(imread(image_file));


% obtain the vector
im_vec = reshape(im,1,[]);



[~,N] = size(im_vec);



% function ceil() is used to round up of a integer

length_one = ceil(N/2);


im_L0 = im_vec(1:length_one);

im_R0 = im_vec(length_one+1:N);



end




