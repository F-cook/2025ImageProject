% this function is used to test the bin to dec array transform function 


% set the random seed

rng(100);


% construct the bin array


bin_array = randi([0,1],1,32);


% transform it into dec array

dec_array = bin_array_to_dec_array(bin_array);






