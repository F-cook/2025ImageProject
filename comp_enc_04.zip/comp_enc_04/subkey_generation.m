% this function is used to obtain the subkeys from the key

% the whole key has 240 bits, which will be splited into three subkeys
% each subkey has 80 bits



function [sub_key_1,sub_key_2,sub_key_3] = subkey_generation(key_all)



sub_key_1 = key_all(1:80);

sub_key_2 = key_all(81:160);

sub_key_3 = key_all(161:240);



end

