% this function is used to obtian the compression information 
% include the size of ini_im

% this function is used to obtain the four part after compression

% the completed prediction error image
% the compressed errors
% P, which is the parameter of TSGD
% k, which is the complement information of bin to pixel 
% s, which is the times of 256*256, which determines the original im size
% s, also split the err_im from compressed result



function [err_im,imi_pixel,P,k,s] = compress_five_part(ini_im)




% obtain the predict image with the first row and col unchanged

err_im = predict_complete(ini_im);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% obtain the all_error_matrix

[M,N] = size(err_im);
all_error_matrix = err_im(2:M,2:N);
all_error_matrix_vector = all_error_matrix(:);


% add the s

s = M/256;


% obtain the parameter of TSGD 

P = TSGD_par(err_im);
P = round(P,4);


% obtain the probability matrix

useful_matrix = TSGD_prob_matrix(P);


% obtain the symbols and their frequency

symbols_err = useful_matrix(1,:);
freq_err = useful_matrix(2,:);




% change one value to make the process normal
freq_err(end) = freq_err(end) + 1 - sum(freq_err);




% construct the Huffman tree, which is very important, it is the core

[dict, ~] = huffmandict(symbols_err, freq_err);


% let us encoding

imi_compressed_bin = huffmanenco(all_error_matrix_vector, dict);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

original_imi = imi_compressed_bin';

% transform it into pixel values and with complement number

[k,imi_pixel] = bin_sec_pixel(original_imi);




end















