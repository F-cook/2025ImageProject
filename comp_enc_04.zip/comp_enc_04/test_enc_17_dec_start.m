% this page is used to test the decryption process


% input: final_im, keys
% output: original_im


% prepare the key 
rng(124);
key_all = randi([0,1],1,240);
[subkey_1,subkey_2,subkey_3] = subkey_generation(key_all);



% recover the vector

final_im_vec_r = reshape(final_im,1,[]);


[~,N] = size(final_im_vec_r);
length_one = ceil(N/2);
length_two = N - length_one;


L3_r = final_im_vec_r(1:length_two);
R3_r = final_im_vec_r(length_two+1:N);


% three round deryption


[L2_r,R2_r] = dec_round(L3,R3,subkey_3);

[L1_r,R1_r] = dec_round(L2_r,R2_r,subkey_2);

[L0_r,R0_r] = dec_round(L1_r,R1_r,subkey_1);


% show the original image

im_ini_vec_r = [L0_r,R0_r];

im_compressed_square_r = reshape(im_ini_vec_r,sqrt(length(im_ini_vec_r)),sqrt(length(im_ini_vec_r)));

% imshow(uint8(im_compressed_square_r));



