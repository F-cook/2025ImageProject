% this page is used to compute the probabilities of TSGD
% prepare for the Huffman code




% obtain the necessary data


% obtain the ini_im and new_im, and pred_error_im

ini_im = double(imread("5.1.09.tiff"));

err_im = predict_complete(ini_im);



% obtain the parameter of TSGD 

P = TSGD_par(err_im);



% create a matrix which has three rows, the first is pixel value
% the second is probability of theory, the third is real 


TSGD_matrix = zeros(2,255*2+1);


% assignment to the first row

for i = 1:1:511
    TSGD_matrix(1,i) = i - 256;
end


% assignment to the second row


for i = 1:1:511
    TSGD_matrix(2,i) = TSGD_prob(P,TSGD_matrix(1,i));
end



% assignment to the third row

for i = 1:1:511
    TSGD_matrix(3,i) = real_prob(TSGD_matrix(1,i),err_im); 
end


% test the sum of probability

% TSGD_test = TSGD_matrix(2,:);

% sum_prob = sum(TSGD_test);

% The above is an incomprehensible result


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


x_coordinate = TSGD_matrix(1,:);
y_coordinate_1 = TSGD_matrix(2,:);
y_coordinate_2 = TSGD_matrix(3,:);
plot(x_coordinate,y_coordinate_1,'-r',x_coordinate,y_coordinate_2,'-b');
% plot(x_coordinate,y_coordinate_1,'-r');
% plot(x_coordinate,y_coordinate_2,'-b');
imshow;






