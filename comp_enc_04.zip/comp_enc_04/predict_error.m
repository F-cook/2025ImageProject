% this function is used to generate the final prediction image with errors

function pred_im = predict_error(ini_im,new_im)



[M,N] = size(ini_im);


% copy the first row and first col



for i = 1:1:M
    pred_im(i,1) = ini_im(i,1);
end

for j = 1:1:N
    pred_im(1,j) = ini_im(1,j);
end


for i = 2:1:M
    for j = 2:1:N
        pred_im(i,j) = new_im(i,j) - ini_im(i,j);
    end
end







end




