% this page is used to implement the diffusion with AES sbox


% read the Sbox

AES_Sbox_dec = readmatrix("AESboxDec.txt");


% test the substitution function
% ox 12 C9, AB 62
% dec 18 201, 171 98

original_vector = [18 171 255 0];

diffused_vector = Sbox_transform_forward(original_vector,AES_Sbox_dec);
% diffused_vector = Sbox_transform_backward(original_vector,AES_Sbox_dec);

% The direction of forward and backward are constracted
% therefore, create an unambiguous function
% but at last, modify the original function is my choice

original_vector_r = Sbox_transform_backward(diffused_vector,AES_Sbox_dec);














