% this function is used to obtain the matrix which has rules information

function rec_matrix = rule_to_matrix(num_dec)

rec_matrix = zeros(1,8);

num_bin = dec2bin(num_dec,8);


for i = 1:1:8
    rec_matrix(i) = str2double(num_bin(i));
end



end

