% this page is used to futher intergrate the compression process




% load the data

ini_im = double(imread("5.1.09.tiff"));




% obtain the unfinished results

[err_im,imi_pixel,P,k,s] = compress_five_part(ini_im);





% obtiain the first col and row of err_im 

err_im_first = err_im_first_obtain(err_im);



% transform P into P1 and P2 , which are two pixel values

P2 = mod(P * 10000,100);

P1 = (P*10000 - P2)/100;

P_r = P1 * 0.01 + P2 * 0.0001;


% test a simple function which is used to combine multiple vector
% the result is that the vectors can be combined directly


%{

A = [0 0 0 0];
B = [1 1 1];
C = [2 2];

D = [A,B,C];

%}



% obtain the final compressed image in pixel values

final_imi_compressed = [err_im_first,imi_pixel,P1,P2,k,s];









