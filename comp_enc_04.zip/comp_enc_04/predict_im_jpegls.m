% this function is used to generate the prediction image with 
% JPEG-LS fixed method



function new_im = predict_im_jpegls(ini_im)

[M,N] = size(ini_im);


% construct the prediction image
new_im = zeros(M,N);


% first, copy the first row and first col
for i = 1:1:M
    new_im(i,1) = ini_im(i,1);
end

for j = 1:1:N
    new_im(1,j) = ini_im(1,j);
end



% second, lets predict!


for i = 2:1:M
    for j = 2:1:N
        a = ini_im(i,j-1);
        b = ini_im(i-1,j);
        c = ini_im(i-1,j-1);
        if c >= max(a,b)
            x = min(a,b);
        elseif c <= min(a,b)
            x = max(a,b);
        else
            x = a+b-c;
        end
        new_im(i,j) = x;
    end
end


end



