% this page is used to construct the function of bin array to dec


rng(0);


% construct the data 

bin_array = randi([0,1],1,16);




% function bin2dec() needs string of bin form

bin_array_string = num2str(bin_array(1:8));

% transform

dec_form = bin2dec(bin_array_string);



% construct the record matrix

dec_form_matrix = [];

% try to transform all of the array


[~,N] = size(bin_array);


for i = 1:8:N
    bin_string = num2str(bin_array(i:i+7));
    dec_one_form = bin2dec(bin_string);
    dec_form_matrix = [dec_form_matrix,dec_one_form];
end












