% this page is used to test the improved CA_PRNG


% read the image 

% im_compressed_square  = double(imread("figures\5.1.12.tiff"));
% 
im_compressed_square = [12 25 30; 52 23 255; 36 23 46];




% prepare the key 
% the key is very very important
rng(124);
secret_key = randi([0,1],1,120);



% split it into two part, L0 and R0

[L0,R0] = im_square_split(im_compressed_square);


% encryption the first round

[L1,R1] = enc_round(L0,R0,secret_key);










