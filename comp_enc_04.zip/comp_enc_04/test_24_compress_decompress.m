% maybe this page is an end of compression






% load the data

ini_im = double(imread("5.1.09.tiff"));


% compress the image

imi_compressed = final_imi_compressed_obtain(ini_im);


% decompress it 

% ini_im_r = final_decompress(imi_compressed);


% imshow(uint8(ini_im_r));



% compute the compression rate

%{

[MM,NN] = size(ini_im);
[M,N] = size(imi_compressed);

rate = (M*N)/(MM*NN);

%}


% compute the compression rate with function 

rate = compress_rate_obtain(ini_im,imi_compressed);











