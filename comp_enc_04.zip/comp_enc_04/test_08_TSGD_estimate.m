% this page is used to estimate the parameters of probability distribution
% this page introduces the computing thoery of TSGD


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% suppose the prediction error follow the two-sided geometric distribution

% probability mass function (PMF) is , which is similar to probability desity
% function (PDF), the difference is that the former is descrete

% P(X = k) = (1-p)/(1+p)*p^(abs(k)), k belong Z.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% estimation by the method of mo-menu

% 2P/(1-P)^2 = S^2

% P = ( S^2 + 1 +- sqrt( 2 * S^2 + 1) ) / S^2

% P = ( var_s + 1 + sqrt( 2 * var_s + 1) ) / var_s
% P = ( var_s + 1 - sqrt( 2 * var_s + 1) ) / var_s
%  0 < P < 1


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


















