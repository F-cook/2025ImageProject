% this function is used to complete the predict function

function err_im = predict_complete(ini_im)


new_im = predict_im_jpegls(ini_im);

err_im = predict_error_pro(ini_im,new_im);


end



