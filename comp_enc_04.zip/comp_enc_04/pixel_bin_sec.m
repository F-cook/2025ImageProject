% this function is used to transform the pixel values into binary sequence
% with complement number, recover the original image data


function original_imi_r = pixel_bin_sec(imi_pixel,k)



% copy it directly from test_17


imi_bin_r = [];
    

[~,N] = size(imi_pixel);


for count = 1:1:N
    pixel_first_dec = imi_pixel(count);
    pixel_first_bin = dec2bin((pixel_first_dec),8);
    pixel_vector = [];

    for i = 1:1:8
        pixel_vector(i) = str2num(pixel_first_bin(i));
    end

    imi_bin_r = [imi_bin_r,pixel_vector];

end



original_imi_r = imi_bin_r(1:(length(imi_bin_r)-k));










end


