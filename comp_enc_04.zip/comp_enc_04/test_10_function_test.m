% this page is used to test the functions which implement the previous
% units



% obtain the ini_im and new_im, and pred_error_im

ini_im = double(imread("5.1.09.tiff"));

err_im = predict_complete(ini_im);



% obtain the parameter of TSGD 

P = TSGD_par(err_im);



% compute the estimation probability of 0


prob_TSGD_0 = TSGD_prob(P,0); 


% compute the real probability of 0


prob_real_0 = real_prob(0,err_im); 





