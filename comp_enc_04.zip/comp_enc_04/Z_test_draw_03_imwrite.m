% maybe the imwrite() is better for obtain my figures



% give the values

img_1 = uint8(im_ini);
% img_2 = uint8(im_compressed_square);
img_3 = uint8(final_im);
img_4 = uint8(im_ini_r);

imwrite(img_1,'save_images/im09.png');
% imwrite(img_2,'save_images/im_compress.png');
imwrite(img_3,'save_images/im09_encryption.png');
imwrite(img_4,'save_images/im09_recover.png');

