% this function is used to transform the error prediction first row, col
% into one vector

function err_im_first = err_im_first_obtain(err_im)

% obtain the first row and first col of err_im
% directly obtian   A(1:2,3:4)


[M,~] = size(err_im);

err_im_first_row = err_im(1:1,:);

err_im_first_col_except_one = err_im(2:M,1);

err_im_first_col_except_one = err_im_first_col_except_one';


% conbine the two parts

err_im_first = [err_im_first_row,err_im_first_col_except_one];










end

