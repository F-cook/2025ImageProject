% this page is used to imitate the Huffman coding example 



% obtain the necessary data


% obtain the ini_im and new_im, and pred_error_im

% ini_im = double(imread("5.1.09.tiff"));




% test the impact of different images on compression 
% 5.1.09 rate 0.659892349096501  about 66%
% 5.1.10 rate 0.739702037677816  about 74%
% 5.1.11 rate 0.482735486351403  about 48%
% 5.1.12 rate 0.575799692425990  about 58%

% 5.1.12 round_P rate 0.575799692425990  about 58%
% there has no significant effect on compression



ini_im = double(imread("5.1.12.tiff"));








err_im = predict_complete(ini_im);

% obtain the parameter of TSGD 

P = TSGD_par(err_im);

P = round(P,4);





% obtain the probability matrix

useful_matrix = TSGD_prob_matrix(P);




% obtain the all_error_matrix

[M,N] = size(err_im);
all_error_matrix = err_im(2:M,2:N);
all_error_matrix_vector = all_error_matrix(:);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% obtain the symbols and their frequency

symbols_err = useful_matrix(1,:);
freq_err = useful_matrix(2,:);


% construct the Huffman tree, which is very important, it is the core

[dict, avglen] = huffmandict(symbols_err, freq_err);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% let us encoding

imi_compressed_bin = huffmanenco(all_error_matrix_vector, dict);
































