% this page compress the image with just one step

% the compressed structure 
% final_imi_compressed = [err_im_first,imi_pixel,P1,P2,k,s];




% load the data

ini_im = double(imread("5.1.09.tiff"));


% compress the image

imi_compressed = final_imi_compressed_obtain(ini_im);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% the compressed structure 
% final_imi_compressed = [err_im_first,imi_pixel,P1,P2,k,s];

% err_im,     the completed prediction error image, the first col and row 
% imi_pixel,  the compressed errors
% P, which is the parameter of TSGD
% k, which is the complement information of bin to pixel 
% s, which is the times of size of err_im 



% obtain the necessary vectors used for recovering

count_length = length(imi_compressed);

s = imi_compressed(count_length);

k = imi_compressed(count_length-1);

P2 = imi_compressed(count_length-2);

P1 = imi_compressed(count_length-3);

P = P1 * 0.01 + P2 * 0.0001;

err_im_first = imi_compressed(1:(s*256*2-1));

imi_pixel = imi_compressed(s*256*2:count_length-4);




% recover the all_error_matrix with the three part


all_error_matrix = three_part_all_err(imi_pixel,P,k);


% construct the prediction result, i.e., err_im

count_i = s*256;

for i = 1:1:count_i
    err_im(1,i) = err_im_first(i);
end

for i = 1:1:count_i-1
    err_im(i+1,1) = err_im_first(count_i+i);
end

% complete the err_im

[M,N] = size(all_error_matrix);

for i = 1:1:M
    for j = 1:1:N
    err_im(i+1,j+1) = all_error_matrix(i,j);
    end
end


% recover the original image

ini_im_r = recover_error(err_im);







