% this page is used to intergrate the compression unit




% obtain the necessary data



% load the data

ini_im = double(imread("5.1.09.tiff"));

% obtain the predict image with the first row and col unchanged

err_im = predict_complete(ini_im);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% obtain the all_error_matrix

[M,N] = size(err_im);
all_error_matrix = err_im(2:M,2:N);
all_error_matrix_vector = all_error_matrix(:);



% obtain the parameter of TSGD 

P = TSGD_par(err_im);
P = round(P,4);


% obtain the probability matrix

useful_matrix = TSGD_prob_matrix(P);


% obtain the symbols and their frequency

symbols_err = useful_matrix(1,:);
freq_err = useful_matrix(2,:);


% construct the Huffman tree, which is very important, it is the core

[dict, avglen] = huffmandict(symbols_err, freq_err);


% let us encoding

imi_compressed_bin = huffmanenco(all_error_matrix_vector, dict);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% try to use my function directly with col vector

% transform it into pixel values and with complement number
% which is not feasible

original_imi = imi_compressed_bin';

% transform it into pixel values and with complement number

[k,imi_pixel] = bin_sec_pixel(original_imi);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% there are four part need to save 

% the completed prediction error image, the first col and row 
% the compressed errors
% P, which is the parameter of TSGD
% k, which is the complement information of bin to pixel 



























%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% test the decoding process


%{


% recover the original image data

original_imi_r = pixel_bin_sec(imi_pixel,k);



all_error_matrix_vector_r = huffmandeco(imi_compressed_bin, dict);

n = sqrt(length(all_error_matrix_vector_r));

all_error_matrix_r = reshape(all_error_matrix_vector_r,n,n);

%}















