% this new page is used to test the transform between 8-bit binary 
% and decimalism form



% load the data 

imi_bin = [0 1 0 1 0 0 1 0 0 1];

% record the original data

original_imi = imi_bin;






% the number of complementary is k

k = 0;

% add the new elements directly with judge the vector length directly

while mod(length(imi_bin),8) ~= 0
    imi_bin = [imi_bin,0];
    k = k + 1;
end





% transform all the binary elements 


[~,N] = size(imi_bin);

imi_pixel = [];

for i = 1:8:N
    pixel_bin = imi_bin(i:i+7);
    pixel_dec = bin2dec(num2str(pixel_bin));
    imi_pixel = [imi_pixel,pixel_dec];
end




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% recover the imi_pixel 


% transform the first pixel into 8 bit binary 

pixel_first_dec = imi_pixel(1);

% pixel_first_bin = dec2bin(pixel_first_dec);

pixel_first_bin = dec2bin((pixel_first_dec),8);

% the function dec2bin() can transform the number accurately

%{

% num_test = str2num(pixel_first_bin);

num_vector = [];

str_length = length(pixel_first_bin);

% complement it 

while mod(length(imi_bin),8) ~= 0
    imi_bin = [imi_bin,0];
end

%}

pixel_vector = [];

for i = 1:1:8 
    pixel_vector(i) = str2num(pixel_first_bin(i));
end











