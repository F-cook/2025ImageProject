% this function is used to obtain the square image of compressed result


function imi_compressed_plus = square_image_obtain(imi_compressed)



im_compressed_length = length(imi_compressed);


count_k = ceil(sqrt(im_compressed_length));


add_zero_num = count_k^2 - im_compressed_length;



for i = 1:1:add_zero_num
    imi_compressed = [imi_compressed,0];
end


if add_zero_num <= 2
    imi_compressed(end) = add_zero_num;
elseif add_zero_num > 2
    count_time = floor(add_zero_num/255);
    count_mod = mod(add_zero_num,255);
    imi_compressed(end) = count_time;
    imi_compressed(end-1) = count_mod;
end



new_im_length = sqrt(length(imi_compressed));

imi_compressed_plus = reshape(imi_compressed,new_im_length,new_im_length);




end


