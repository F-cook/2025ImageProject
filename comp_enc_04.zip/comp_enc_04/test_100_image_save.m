% this page is used to save images


% load the data
% im_ini = double(imread("figures\5.1.10.tiff"));



% save the data
imwrite(uint8(im_ini),'figures_output\original.png');

% imwrite(uint8(imi_compressed),'figures_output\5.1.10_cte.png');

imwrite(uint8(im_compressed_square),'figures_output\compressed.png');






