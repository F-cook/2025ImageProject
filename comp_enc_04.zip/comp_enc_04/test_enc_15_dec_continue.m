% this page is used to recover the original plaintext in one round


% prepare the key 

rng(124);

key_all = randi([0,1],1,240);

[subkey_1,subkey_2,subkey_3] = subkey_generation(key_all);


% read the Sbox

AES_Sbox_dec = readmatrix("AESboxDec.txt");


% input: L1,R1
% output: L0,R0





% recover the R0 directly

R0_r = L1;


% recover the L0, through the inverse of diffusion and substitution



% recover the random nunmbers

% SHA value obtain

R0_SHA_r = SHA_256_value_obtain_matrix(R0_r);


% construct the initial value of CA PRNG 

CA_ini_r = [R0_SHA_r,subkey_1];


% create the random numbers with CA PRNG

size_need_r = length(R1);
% L0 has the same length with R1

random_numbers_r = CA_PRNG(CA_ini,size_need);





L0_s_d_r = R1;


% inverse diffusion

L0_s_r = diffuse_backward(L0_s_d_r,random_numbers);

% inverse substitution

L0_r = Sbox_transform_backward(L0_s_r,AES_Sbox_dec);






