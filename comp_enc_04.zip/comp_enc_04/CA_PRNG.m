% this function is used to complete the CA PRNG

% ini is a initiate cellular array, 256 + 80 = 336 cells
% num_need is the size of plaintext length


function data_RNG_dec = CA_PRNG(ini,size)


% add the count number to obtain the iterate_num
count_i = length(ini);
count_j = count_i/8;
count_k = ceil(size/count_j);


iterate_num = count_k + 200;

count_num = count_k;


% iterate_num = ceil(size/42) + 200;

% count_num = ceil(size/42);




rule_num = 30;


% let us start 


[~,data_RNG_bin] = CA_variable_iteration(ini,iterate_num,rule_num);



data_RNG_bin_stable = data_RNG_bin(1:(count_num),1:end);

data_RNG_bin_stable_vec = reshape(data_RNG_bin_stable,1,[]);

data_RNG_dec = bin_array_to_dec_array(data_RNG_bin_stable_vec);




end

