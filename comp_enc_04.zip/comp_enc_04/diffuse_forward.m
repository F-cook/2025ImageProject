% this function is used to diffuse


function A_D_vector = diffuse_forward(A_vector,T)

[M,N] = size(A_vector);


A_D_vector = zeros(1,M*N);
A_D_vector(1) = mod(bitxor(A_vector(1),T(1)),256);



% forward process:

for i = 2:1:M*N
    if mod(i,2) == 0
        A_D_vector(i) = mod(bitxor(bitxor(A_D_vector(i-1),T(i)),A_vector(i)),256);
    else
        A_D_vector(i) = mod(A_D_vector(i-1) + A_vector(i) + T(i),256);
    end
end





end