% this function is used to obtain the predict error matrix 
% with the difference between real value and prediction value


% the right way of computing errors is using real value - prediction


function pred_im = predict_error_pro(ini_im,new_im)



[M,N] = size(ini_im);


% copy the first row and first col



for i = 1:1:M
    pred_im(i,1) = ini_im(i,1);
end

for j = 1:1:N
    pred_im(1,j) = ini_im(1,j);
end


for i = 2:1:M
    for j = 2:1:N
        pred_im(i,j) = ini_im(i,j) - new_im(i,j);
    end
end







end















