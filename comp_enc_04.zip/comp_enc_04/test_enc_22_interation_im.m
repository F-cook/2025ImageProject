% this page is used to improve the encryption


rng(124);
secret_key = randi([0,1],1,128);




% load the image
% im_ini = double(imread("useful_figures\5.3.02.tiff"));


% 7.1.10
% boat.512
% gray21.512
% ruler.512


im_compressed_square = double(imread("figures\7.1.05.tiff"));



enc_before = im_compressed_square;









% change pixel for NPCR or UACI
enc_before(2,2) = 100; 
%{
%}




% im_ini = [12 25 30; 52 23 255; 36 23 46];

enc_after = encrypt_three_round_im(enc_before,secret_key);


% save the encryption image  _01

imwrite(uint8(enc_after),'figures_output\7.1.05_enc_01.png');










% test the recover
% 
% enc_before_r = decryption_three_round_im(enc_after,secret_key);

% judge_value_enc = isequal(enc_before_r,enc_before);

% imshow(uint8(enc_before_r));

% 



% save the encryption image

% imwrite(uint8(enc_after),'figures_output\_enc.png');

