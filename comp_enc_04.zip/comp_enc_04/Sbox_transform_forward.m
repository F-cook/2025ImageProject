% This function is used to transform a vector with S-box


function new_vector = Sbox_transform_forward(old_vector,lookup_table)


[~,length] = size(old_vector);


for i = 1:1:length
    new_vector(i) = lookup_forward(old_vector(i),lookup_table);
end


end



