% this function is used to obtain the compressed image 
% which before becoming the square matrix

function imi_compressed_r = compressed_im_from_square(imi_compressed_square)



if imi_compressed_square(end-1) == 0
    count_k = imi_compressed_square(end);
else
    count_k = imi_compressed_square(end) * 255 + imi_compressed_square(end-1);
end

[M,N] = size(imi_compressed_square);

original_length = M*N - count_k;

imi_compressed_r = imi_compressed_square(1:original_length);







end
