% this page is used to recover the compressed data




% recover, obtain the compressed image
im_compressed_r = compressed_im_from_square(im_compressed_square);


% detemine it is the same or not
% judge_value = isequal(im_compressed,im_compressed_r);


% decompress the compressed image

im_ini_r = final_decompress(im_compressed_r);


% show the image

imshow(uint8(im_ini_r));



