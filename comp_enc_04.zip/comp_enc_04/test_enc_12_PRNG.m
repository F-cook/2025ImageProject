% this page is used to construct the PRNG with 
% SHA-value and Cellular Automata




rng(124);



% previously


ini = randi([0,1],1,336);

% iterate_num = 100;


M = 10;
N = 20;

iterate_num = ceil(M*N/42) + 200;

count_num = ceil(M*N/42);

rule_num = 30;


% let us start 


tic

[~,data_RNG_bin] = CA_variable_iteration(ini,iterate_num,rule_num);

toc




data_RNG_bin_stable = data_RNG_bin(1:(count_num),1:end);

data_RNG_bin_stable_vec = reshape(data_RNG_bin_stable,1,[]);

data_RNG_dec = bin_array_to_dec_array(data_RNG_bin_stable_vec);











