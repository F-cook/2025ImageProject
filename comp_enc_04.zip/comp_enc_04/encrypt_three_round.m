% this page is used to  integrate the functions
% of test_enc_16_one_round


function final_im = encrypt_three_round(im_compressed_square,key_all)


[subkey_1,subkey_2,subkey_3] = subkey_generation(key_all);


% split it into two part, L0 and R0

[L0,R0] = im_square_split(im_compressed_square);



% encryption the first round

[L1,R1] = enc_round(L0,R0,subkey_1);

% encrypt the remaining rounds

[L2,R2] = enc_round(L1,R1,subkey_2);

[L3,R3] = enc_round(L2,R2,subkey_3);


final_im_vec = [L3,R3];

final_im = reshape(final_im_vec,sqrt(length(final_im_vec)),sqrt(length(final_im_vec)));




end

