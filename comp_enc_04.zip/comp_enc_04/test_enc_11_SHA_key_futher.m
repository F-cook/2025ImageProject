% this page is used to test the hash value and key futher


% test the hash function

%{

A = [23 44 56 56];

sha_value_A = SHA_256_value_obtain_matrix(A);

%}




rng(124);

key_all = randi([0,1],1,240);

%{

sub_key_1 = key_all(1:80);

sub_key_2 = key_all(81:160);

sub_key_3 = key_all(161:240);

%}


% test the subkey generation function

[subkey_1,subkey_2,subkey_3] = subkey_generation(key_all);





















