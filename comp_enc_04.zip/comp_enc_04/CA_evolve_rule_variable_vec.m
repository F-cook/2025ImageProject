% this function is used to evolve the whole vector with different rules


function new_ini = CA_evolve_rule_variable_vec(ini,rule_num)


% construct the new vector

new_ini = [];


count_middle = length(ini) - 1;
count_length = length(ini);





for i = 2:1:count_middle
    new_ini(i) = CA_evolve_rule_variable(ini(i-1),ini(i),ini(i+1),rule_num);
end



% evolution the first and the last value

new_ini(1) = CA_evolve_rule_variable(ini(count_length),ini(1),ini(2),rule_num);

new_ini(count_length) = CA_evolve_rule_variable(ini(count_middle),ini(count_length),ini(1),rule_num);






end
