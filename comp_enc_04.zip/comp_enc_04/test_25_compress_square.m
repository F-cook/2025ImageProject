% this page is used to test compress 
% and another thing is construct a square image


% load the data
ini_im = double(imread("5.1.09.tiff"));


% compress the image
imi_compressed = final_imi_compressed_obtain(ini_im);
%{

% decompress it 

ini_im_r = final_decompress(imi_compressed);

%}









