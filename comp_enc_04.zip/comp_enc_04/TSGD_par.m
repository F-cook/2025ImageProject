% this function is used to obtian the parameter P of TSGD

function P = TSGD_par(err_im)


% obtain the matrix which only include errors

[M,N] = size(err_im);


% maybe the inline function is more fast

all_err_im = err_im(2:M,2:N);



% transform the matrix into a 1D vector

all_err_im_vec = all_err_im(:)';


% function var() is used to compute the variance of a matrix of each col

var_s = var(all_err_im_vec,1,2);



P1 = ( var_s + 1 + sqrt( 2 * var_s + 1) ) / var_s; 
P2 = ( var_s + 1 - sqrt( 2 * var_s + 1) ) / var_s;

if P1 > 0 && P1 < 1
    P = P1;
else
    P = P2;
end


end

