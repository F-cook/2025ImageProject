% this function is used to futher test the CA PRNG



% test the CA PRNG 


rng(124);


size = 256*256/2;



ini = randi([0,1],1,336);



random_numbers = CA_PRNG(ini,size);














