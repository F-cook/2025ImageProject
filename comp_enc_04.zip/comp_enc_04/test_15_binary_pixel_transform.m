% this page is used to create some functions which transform various binary
% to 8-bit pixels

% it should returns the complementary number and pixel form data


% load the data 

imi_bin = [0 1 0 1 0 0 1 0 0 1];

% record the original data

original_imi = imi_bin;

%{

% transform it into string form

imi_bin_str = num2str(imi_bin);

% may be it dosen't need to be converted to string form

%}


% the number of complementary is k

k = 0;

%{

while mod(length(imi_bin_str),8) ~= 0
    imi_bin_str = [imi_bin_str,'0'];
    k = k + 1;
end

%}


% add the new elements directly with judge the vector length directly

while mod(length(imi_bin),8) ~= 0
    imi_bin = [imi_bin,0];
    k = k + 1;
end


% transform the first 8 bits into a pixel

pixel_bin = imi_bin(1:8);

% pixel_bin_str = num2str(pixel_bin);

% Perhaps it never needs to be converted into a string
% or I was wrong

% pixel_dec = bin2dec(pixel_bin_str);




% transform all the binary elements 


[~,N] = size(imi_bin);

imi_pixel = [];

for i = 1:8:N
    pixel_bin = imi_bin(i:i+7);
    pixel_dec = bin2dec(num2str(pixel_bin));
    imi_pixel = [imi_pixel,pixel_dec];
end




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




% the inverse process, recover the original bin with number k

% imi_bin_r = imi_bin(1:length(imi_bin)-k);














