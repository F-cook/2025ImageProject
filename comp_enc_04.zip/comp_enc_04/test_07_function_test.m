% this page is used to summarize the code finished so far


% obtain the ini_im and new_im, and pred_im


% ini_im = [1 2 3; 4 5 6 ; 7 8 9];



ini_im = double(imread("5.1.09.tiff"));


%{

new_im = predict_im_jpegls(ini_im);

err_im = predict_error_pro(ini_im,new_im);

%}


err_im = predict_complete(ini_im);


% recover the original image with err_im

ini_im_re = recover_error(err_im);



% test with eyes
% imshow(uint8(ini_im_re));

% test with difference comparation
% diff_matrix = diff_two_images(ini_im,ini_im_re);
% real_difference = sum(sum(diff_matrix));





