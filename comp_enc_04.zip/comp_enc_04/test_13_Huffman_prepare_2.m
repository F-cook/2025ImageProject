% this page is used to implement a Huffman codec


% page link: https://blog.csdn.net/qq_42912425/article/details/138245109


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% load the image and obtain the probabilities of pixels

% load the image

img = double(imread("5.1.09.tiff"));


% transform it into 1D vector

imgVector = img(:);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% obtain the probabilities of pixels




symbols = unique(imgVector);

% function unique() returns a sorted list of non repeating elements




freq = histcounts(imgVector, [symbols; max(symbols)+1]);

% function histcounts() returns the information of histogram
% which is similar to the hist()


freq = freq / sum(freq);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% show the frequency

%{

[M,N] = size(freq);

freq_matrix = zeros(2,M*N);

for i = 1:1:M*N
    freq_matrix(1,i) = symbols(i,1);
    freq_matrix(2,i) = freq(1,i);
end


%}



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% construct the huffman tree

[dict, avglen] = huffmandict(symbols, freq);


% the function huffmandict() returns the dictionary of huffman tree
% it is the core of huffman coding
% the form of it is usually represented as 
% [dict, avglen] = huffmandict(symbols, prob)


% the above two vetor have the same length
% the second,i.e.,the prob's sum is 1



% the first parameter is dictionary
% the second parameter is the average codec length




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% let us encoding

encodedImg = huffmanenco(imgVector, dict);


% the function huffmanenco(sig,dict) is used for huffman coding
% the first is data, the second is dictionary

% the output is a long double vector with 0-1 





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% the following is decoding process


decodedImgVector = huffmandeco(encodedImg, dict);
decodedImg = reshape(decodedImgVector, size(img));








