% this page is used to test one round encryption and decryption


% read the image 

% im_compressed_square  = double(imread("figures\5.1.12.tiff"));

% im_compressed_square = [12 25 30; 52 23 255; 36 23 46];



% im_compressed_square  = double(imread("figures\5.1.10.tiff"));



% prepare the key 
% the key is very very important
rng(124);
key_all = randi([0,1],1,240);
[subkey_1,subkey_2,subkey_3] = subkey_generation(key_all);


% split it into two part, L0 and R0

[L0,R0] = im_square_split(im_compressed_square);



% encryption the first round

[L1,R1] = enc_round(L0,R0,subkey_1);

% encrypt the remaining rounds

[L2,R2] = enc_round(L1,R1,subkey_2);

[L3,R3] = enc_round(L2,R2,subkey_3);


final_im_vec = [L3,R3];

final_im = reshape(final_im_vec,sqrt(length(final_im_vec)),sqrt(length(final_im_vec)));

% imshow(uint8(final_im));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% decryption 

%{

[L2_r,R2_r] = dec_round(L3,R3,subkey_3);

[L1_r,R1_r] = dec_round(L2_r,R2_r,subkey_2);

[L0_r,R0_r] = dec_round(L1_r,R1_r,subkey_1);

%}

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




