% this function is used to obtain the final compressed result


% the completed prediction error image, the first col and row 
% the compressed errors
% P, which is the parameter of TSGD
% k, which is the complement information of bin to pixel 
% s, which is the times of size of err_im 





function final_imi_compressed = final_imi_compressed_obtain(ini_im)



% obtain the unfinished results

[err_im,imi_pixel,P,k,s] = compress_five_part(ini_im);


% obtiain the first col and row of err_im 

err_im_first = err_im_first_obtain(err_im);


% transform P into P1 and P2 , which are two pixel values

P2 = mod(P * 10000,100);

P1 = (P*10000 - P2)/100;

P_r = P1 * 0.01 + P2 * 0.0001;

% obtain the final compressed image in pixel values

final_imi_compressed = [err_im_first,imi_pixel,P1,P2,k,s];



end