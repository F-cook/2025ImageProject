% this page is used to compute the delay parameter of TSGD


% obtain the ini_im and new_im, and pred_error_im

ini_im = double(imread("5.1.09.tiff"));

err_im = predict_complete(ini_im);


% obtain the matrix which only include errors

[M,N] = size(err_im);

% all_err_im = zeros(M-1,N-1);


% the following is a simple cycle

%{

for i = 1:1:M-1
    for j = 1:1:N-1
        all_err_im(i,j) = err_im(i+1,j+1);
    end
end

%}


% maybe the inline function is more fast

all_err_im = err_im(2:M,2:N);




% transform the matrix into a 1D vector

% all_err_im_vec = reshape(all_err_im,1,(M-1)*(N-1));

all_err_im_vec = all_err_im(:)';





% function var() is used to compute the variance of a matrix of each col

% var_s = var(all_err_im);



var_s = var(all_err_im_vec,1,2);
% var_s = var(all_err_im_vec,0,2);


P1 = ( var_s + 1 + sqrt( 2 * var_s + 1) ) / var_s; 
P2 = ( var_s + 1 - sqrt( 2 * var_s + 1) ) / var_s;

if P1 > 0 && P1 < 1
    P = P1;
else
    P = P2;
end



%{


% test the probability of zero

% P(X = k) = (1-p)/(1+p)*p^(abs(k)), k belong Z.

P_test_0 = (1-P)/(1+P)*P^(abs(0));


[M,N] = size(all_err_im);

count_x = 0;

for i = 1:1:M
    for j = 1:1:N
        if all_err_im(i,j) == 0
            count_x = count_x + 1;
        end
    end
end

rate_x = count_x / (M*N);


% The results showed that the difference was not significant


%}






% test the probability of one / ten 

% P(X = k) = (1-p)/(1+p)*p^(abs(k)), k belong Z.

P_test_0 = (1-P)/(1+P)*P^(abs(0));


[M,N] = size(all_err_im);

count_x = 0;

for i = 1:1:M
    for j = 1:1:N
        if all_err_im(i,j) == 0
            count_x = count_x + 1;
        end
    end
end

rate_x = count_x / (M*N);









