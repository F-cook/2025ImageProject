% this function is used to obtain both the theory and real probability of 
% different values distributions




function TSGD_matrix = all_prob_matrix(P,err_im)



% create a matrix which has three rows, the first is pixel value
% the second is probability of theory, the third is real 


TSGD_matrix = zeros(2,255*2+1);


% assignment to the first row

for i = 1:1:511
    TSGD_matrix(1,i) = i - 256;
end


% assignment to the second row


for i = 1:1:511
    TSGD_matrix(2,i) = TSGD_prob(P,TSGD_matrix(1,i));
end



% assignment to the third row

for i = 1:1:511
    TSGD_matrix(3,i) = real_prob(TSGD_matrix(1,i),err_im); 
end






end









