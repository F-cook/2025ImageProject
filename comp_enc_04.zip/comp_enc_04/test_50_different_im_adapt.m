% this page is used to test the compression rate of different images


% read the image from a file

% 5.1.12.tiff
% 5.2.10.tiff
% 5.3.02.tiff



% 256, 5.1.09 - 5.1.12


% im_ini = double(imread("figures\5.1.09.tiff"));


% im_ini = double(imread("figures\3.2.25.tiff"));

% 512

% im_ini = double(imread("figures\5.2.08.tiff"));

% 1024
% 
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% im_ini = double(imread("figures\7.1.10.tiff"));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% im_ini = double(imread("figures\boat.512.tiff"));
% im_ini = double(imread("figures\gray21.512.tiff"));
im_ini = double(imread("figures\ruler.512.tiff"));
% 




% compress the image 

im_compressed = final_imi_compressed_obtain(im_ini);


% obtain the square image

im_compressed_square = square_image_obtain(im_compressed);

% compute the second compression rate 

compression_percentage = 1 - compress_rate_obtain(im_ini,im_compressed_square);

% BPP = compression_rate_2 * 8;












% compute the first or directly compression rate 

% compression_rate_1 = compress_rate_obtain(im_ini,im_compressed);










% imshow(uint8(im_compressed_square));

% imshow(uint8(im_ini));


% exportgraphics(gcf, 'figures_output\original.tif', 'ContentType', 'image', 'BackgroundColor', 'none');

% exportgraphics(gcf, 'figures_output\compressed.tif', 'ContentType', 'image', 'BackgroundColor', 'none');

% exportgraphics(gcf, 'figures_output\final_CTE.tif', 'ContentType', 'image', 'BackgroundColor', 'none');




