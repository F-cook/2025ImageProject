% this function is used to record the encryption process of one round

function [L1,R1] = enc_round(L0,R0,subkey_1)


% read the Sbox

AES_Sbox_dec = readmatrix("AESboxDec.txt");



% R0 generation SHA value then use CA PRNG 



% SHA value obtain

R0_SHA = SHA_256_value_obtain_matrix(R0);

% construct the initial value of CA PRNG 

CA_ini = [R0_SHA,subkey_1];


% create the random numbers with CA PRNG

size_need = length(L0);

random_numbers = CA_PRNG(CA_ini,size_need);


% and at last L1 is obtained directly using R0

L1 = R0;




% L0, substitution, diffusion 

% substitution

L0_s = Sbox_transform_forward(L0,AES_Sbox_dec);


% diffusion

L0_s_d = diffuse_forward(L0_s,random_numbers);


% finally, R1 is obtained using L0 result after substitution and diffusion 

R1 = L0_s_d;



end

